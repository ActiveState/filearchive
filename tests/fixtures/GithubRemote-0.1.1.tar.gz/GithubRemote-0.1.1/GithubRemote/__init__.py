import os.path

CONFIG_PATH = os.path.expanduser('~/.githubremote.cfg')
